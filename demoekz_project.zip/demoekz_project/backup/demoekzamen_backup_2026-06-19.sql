BEGIN TRANSACTION;
CREATE TABLE "Category" ("ID" INTEGER PRIMARY KEY AUTOINCREMENT, "Name" VARCHAR(200) NOT NULL);
INSERT INTO "Category" VALUES(1,'Общестроительные материалы');
INSERT INTO "Category" VALUES(2,'Стеновые и фасадные материалы');
INSERT INTO "Category" VALUES(3,'Сухие строительные смеси и гидроизоляция');
INSERT INTO "Category" VALUES(4,'Ручной инструмент');
INSERT INTO "Category" VALUES(5,'Защита лица, глаз, головы');
CREATE TABLE "Manufactures" ("ID" INTEGER PRIMARY KEY AUTOINCREMENT, "Name" VARCHAR(200) NOT NULL);
INSERT INTO "Manufactures" VALUES(1,'М500');
INSERT INTO "Manufactures" VALUES(2,'Изостронг');
INSERT INTO "Manufactures" VALUES(3,'Knauf');
INSERT INTO "Manufactures" VALUES(4,'MixMaster');
INSERT INTO "Manufactures" VALUES(5,'ЛСР');
INSERT INTO "Manufactures" VALUES(6,'ВОЛМА');
INSERT INTO "Manufactures" VALUES(7,'Vinylon');
INSERT INTO "Manufactures" VALUES(8,'Павловский завод');
INSERT INTO "Manufactures" VALUES(9,'Weber');
INSERT INTO "Manufactures" VALUES(10,'Hesler');
INSERT INTO "Manufactures" VALUES(11,'Armero');
INSERT INTO "Manufactures" VALUES(12,'Wenzo Roma');
INSERT INTO "Manufactures" VALUES(13,'KILIMGRIN');
INSERT INTO "Manufactures" VALUES(14,'Исток');
INSERT INTO "Manufactures" VALUES(15,'RUIZ');
INSERT INTO "Manufactures" VALUES(16,'Husqvarna');
INSERT INTO "Manufactures" VALUES(17,'Delta');
CREATE TABLE "Orders" (
        "ID" INTEGER PRIMARY KEY AUTOINCREMENT,
        "User_ID" INTEGER NOT NULL REFERENCES "Users"("ID") ON DELETE CASCADE,
        "Product_ID" VARCHAR(50) NOT NULL REFERENCES "Products"("Article") ON DELETE CASCADE,
        "Quantity" INTEGER NOT NULL,
        "Order_Date" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "Status" VARCHAR(20) NOT NULL DEFAULT 'new',
        "Pickup_Address" VARCHAR(500) NOT NULL DEFAULT '',
        "Delivery_Date" TIMESTAMP NULL);
CREATE TABLE "Pickups" (
        "ID" INTEGER PRIMARY KEY AUTOINCREMENT,
        "Zip_Code" VARCHAR(20) NOT NULL,
        "City" VARCHAR(100) NOT NULL,
        "Street" VARCHAR(200) NOT NULL,
        "House" VARCHAR(20) DEFAULT '');
INSERT INTO "Pickups" VALUES(1,'420151','Лесной','Вишневая','32');
INSERT INTO "Pickups" VALUES(2,'125061','Лесной','Подгорная','8');
INSERT INTO "Pickups" VALUES(3,'630370','Лесной','Шоссейная','24');
INSERT INTO "Pickups" VALUES(4,'400562','Лесной','Зеленая','32');
INSERT INTO "Pickups" VALUES(5,'614510','Лесной','Маяковского','47');
INSERT INTO "Pickups" VALUES(6,'410542','Лесной','Светлая','46');
INSERT INTO "Pickups" VALUES(7,'620839','Лесной','Цветочная','8');
INSERT INTO "Pickups" VALUES(8,'443890','Лесной','Коммунистическая','1');
INSERT INTO "Pickups" VALUES(9,'603379','Лесной','Спортивная','46');
INSERT INTO "Pickups" VALUES(10,'603721','Лесной','Гоголя','41');
INSERT INTO "Pickups" VALUES(11,'410172','Лесной','Северная','13');
INSERT INTO "Pickups" VALUES(12,'614611','Лесной','Молодежная','50');
INSERT INTO "Pickups" VALUES(13,'454311','Лесной','Новая','19');
INSERT INTO "Pickups" VALUES(14,'660007','Лесной','Октябрьская','19');
INSERT INTO "Pickups" VALUES(15,'603036','Лесной','Садовая','4');
INSERT INTO "Pickups" VALUES(16,'394060','Лесной','Фрунзе','43');
INSERT INTO "Pickups" VALUES(17,'410661','Лесной','Школьная','50');
INSERT INTO "Pickups" VALUES(18,'625590','Лесной','Коммунистическая','20');
INSERT INTO "Pickups" VALUES(19,'625683','Лесной','8 Марта','');
INSERT INTO "Pickups" VALUES(20,'450983','Лесной','Комсомольская','26');
INSERT INTO "Pickups" VALUES(21,'394782','Лесной','Чехова','3');
INSERT INTO "Pickups" VALUES(22,'603002','Лесной','Дзержинского','28');
INSERT INTO "Pickups" VALUES(23,'450558','Лесной','Набережная','30');
INSERT INTO "Pickups" VALUES(24,'344288','Лесной','Чехова','1');
INSERT INTO "Pickups" VALUES(25,'614164','Лесной','Степная','30');
INSERT INTO "Pickups" VALUES(26,'394242','Лесной','Коммунистическая','43');
INSERT INTO "Pickups" VALUES(27,'660540','Лесной','Солнечная','25');
INSERT INTO "Pickups" VALUES(28,'125837','Лесной','Шоссейная','40');
INSERT INTO "Pickups" VALUES(29,'125703','Лесной','Партизанская','49');
INSERT INTO "Pickups" VALUES(30,'625283','Лесной','Победы','46');
INSERT INTO "Pickups" VALUES(31,'614753','Лесной','Полевая','35');
INSERT INTO "Pickups" VALUES(32,'426030','Лесной','Маяковского','44');
INSERT INTO "Pickups" VALUES(33,'450375','Лесной','Клубная','44');
INSERT INTO "Pickups" VALUES(34,'625560','Лесной','Некрасова','12');
INSERT INTO "Pickups" VALUES(35,'630201','Лесной','Комсомольская','17');
INSERT INTO "Pickups" VALUES(36,'190949','Лесной','Мичурина','26');
CREATE TABLE "Products" (
        "Article" VARCHAR(50) PRIMARY KEY,
        "Name" VARCHAR(200) NOT NULL,
        "number_measure" VARCHAR(50) NOT NULL,
        "Price" DECIMAL(10,2) NOT NULL,
        "Supplier_ID" INTEGER NOT NULL REFERENCES "Suplyers"("ID"),
        "Manufacturer_ID" INTEGER NOT NULL REFERENCES "Manufactures"("ID"),
        "Category_ID" INTEGER NOT NULL REFERENCES "Category"("ID"),
        "Discount" DECIMAL(5,2) NOT NULL DEFAULT 0,
        "Quantity" INTEGER NOT NULL DEFAULT 0,
        "Description" TEXT DEFAULT '',
        "Photo" VARCHAR(200) DEFAULT '');
INSERT INTO "Products" VALUES('PMEZMH','Цемент','шт',440,1,1,1,8,34,'Цемент Евроцемент М500 Д0 ЦЕМ I 42,5 50 кг','PMEZMH.jpg');
INSERT INTO "Products" VALUES('BPV4MM','Пленка техническая','шт',8,2,2,1,8,2,'Пленка техническая полиэтиленовая Изостронг 60 мк 3 м рукав 1,5 м, пог.м','BPV4MM.jpg');
INSERT INTO "Products" VALUES('JVL42J','Пленка техническая','шт',13,2,2,1,4,34,'Пленка техническая полиэтиленовая Изостронг 100 мк 3 м рукав 1,5 м, пог.м','JVL42J.jpg');
INSERT INTO "Products" VALUES('F895RB','Песок строительный','шт',102,3,3,1,6,7,'Песок строительный 50 кг','F895RB.jpg');
INSERT INTO "Products" VALUES('3XBOTN','Керамзит фракция','шт',110,4,4,1,5,21,'Керамзит фракция 10-20 мм 0,05 куб.м','3XBOTN.jpg');
INSERT INTO "Products" VALUES('3L7RCZ','Газобетон','шт',7400,5,5,2,2,20,'Газобетон ЛСР 100х250х625 мм D400','3L7RCZ.jpg');
INSERT INTO "Products" VALUES('S72AM3','Пазогребневая плита','шт',500,6,6,2,5,35,'Пазогребневая плита ВОЛМА Гидро 667х500х80 мм полнотелая','S72AM3.jpg');
INSERT INTO "Products" VALUES('2G3280','Угол наружный','шт',795,7,7,2,9,20,'Угол наружный Vinylon 3050 мм серо-голубой','2G3280.jpg');
INSERT INTO "Products" VALUES('MIO8YV','Кирпич','шт',30,6,6,2,9,31,'Кирпич рядовой Боровичи полнотелый М150 250х120х65 мм 1NF','MIO8YV.jpg');
INSERT INTO "Products" VALUES('UER2QD','Скоба для пазогребневой плиты','шт',25,3,3,2,8,27,'Скоба для пазогребневой плиты Knauf С1 120х100 мм','');
INSERT INTO "Products" VALUES('ZR70B4','Кирпич','шт',16,8,8,2,3,0,'Кирпич рядовой силикатный Павловский завод полнотелый М200 250х120х65 мм 1NF','');
INSERT INTO "Products" VALUES('LPDDM4','Штукатурка гипсовая','шт',500,3,3,3,6,38,'Штукатурка гипсовая Knauf Ротбанд 30 кг','');
INSERT INTO "Products" VALUES('LQ48MW','Штукатурка гипсовая','шт',462,9,9,3,6,33,'Штукатурка гипсовая Knauf МП-75 машинная 30 кг','');
INSERT INTO "Products" VALUES('O43COU','Шпаклевка','шт',750,6,6,3,1,16,'Шпаклевка полимерная Weber.vetonit LR + для сухих помещений белая 20 кг','');
INSERT INTO "Products" VALUES('M26EXW','Клей для плитки, керамогранита и камня','шт',340,3,3,3,8,0,'Клей для плитки, керамогранита и камня Крепс Усиленный серый (класс С1) 25 кг','');
INSERT INTO "Products" VALUES('K0YACK','Смесь цементно-песчаная','шт',160,4,4,3,8,19,'Смесь цементно-песчаная (ЦПС) 300 по ТУ MixMaster Универсал 25 кг','');
INSERT INTO "Products" VALUES('ASPXSG','Ровнитель','шт',711,9,9,3,10,20,'Ровнитель (наливной пол) финишный Weber.vetonit 4100 самовыравнивающийся высокопрочный 20 кг','');
INSERT INTO "Products" VALUES('ZKQ5FF','Лезвие для ножа','шт',65,10,10,4,6,6,'Лезвие для ножа Hesler 18 мм прямое (10 шт.)','');
INSERT INTO "Products" VALUES('4WZEOT','Лезвие для ножа','шт',110,11,11,4,6,17,'Лезвие для ножа Armero 18 мм прямое (10 шт.)','');
INSERT INTO "Products" VALUES('4JR1HN','Шпатель','шт',26,10,10,4,6,7,'Шпатель малярный 100 мм с пластиковой ручкой','');
INSERT INTO "Products" VALUES('Z3XFSP','Нож строительный','шт',63,10,10,4,8,5,'Нож строительный Hesler 18 мм с ломающимся лезвием пластиковый корпус','');
INSERT INTO "Products" VALUES('I6MH89','Валик','шт',326,12,12,4,12,3,'Валик Wenzo Roma полиакрил 250 мм ворс 18 мм для красок грунтов и антисептиков на водной основе с рукояткой','');
INSERT INTO "Products" VALUES('83M5ME','Кисть','шт',122,11,11,4,9,26,'Кисть плоская смешанная щетина 100х12 мм для красок и антисептиков на водной основе','');
INSERT INTO "Products" VALUES('61PGH3','Очки защитные','шт',184,13,13,5,6,25,'Очки защитные Delta Plus KILIMANDJARO (KILIMGRIN) открытые с прозрачными линзами','');
INSERT INTO "Products" VALUES('GN6ICZ','Каска защитная','шт',154,14,14,5,15,8,'Каска защитная Исток (КАС001О) оранжевая','');
INSERT INTO "Products" VALUES('Z3LO0U','Очки защитные','шт',228,15,15,5,9,11,'Очки защитные Delta Plus RUIZ (RUIZ1VI) закрытые с прозрачными линзами','');
INSERT INTO "Products" VALUES('QHNOKR','Маска защитная','шт',251,14,14,5,2,22,'Маска защитная Исток (ЩИТ001) ударопрочная и термостойкая','');
INSERT INTO "Products" VALUES('EQ6RKO','Подшлемник','шт',36,16,16,5,17,22,'Подшлемник для каски одноразовый','');
INSERT INTO "Products" VALUES('81F1WG','Каска защитная','шт',1500,17,17,5,2,13,'Каска защитная Delta Plus BASEBALL DIAMOND V UP (DIAM5UPBCFLBS) белая','');
INSERT INTO "Products" VALUES('0YGHZ7','Очки защитные','шт',700,16,16,5,9,36,'Очки защитные Husqvarna Clear (5449638-01) открытые с прозрачными линзами','');
CREATE TABLE "Roles" ("ID" INTEGER PRIMARY KEY AUTOINCREMENT, "Name" VARCHAR(100) NOT NULL);
INSERT INTO "Roles" VALUES(1,'Администратор');
INSERT INTO "Roles" VALUES(2,'Менеджер');
INSERT INTO "Roles" VALUES(3,'Авторизированный клиент');
CREATE TABLE "Suplyers" ("ID" INTEGER PRIMARY KEY AUTOINCREMENT, "Name" VARCHAR(200) NOT NULL);
INSERT INTO "Suplyers" VALUES(1,'М500');
INSERT INTO "Suplyers" VALUES(2,'Изостронг');
INSERT INTO "Suplyers" VALUES(3,'Knauf');
INSERT INTO "Suplyers" VALUES(4,'MixMaster');
INSERT INTO "Suplyers" VALUES(5,'ЛСР');
INSERT INTO "Suplyers" VALUES(6,'ВОЛМА');
INSERT INTO "Suplyers" VALUES(7,'Vinylon');
INSERT INTO "Suplyers" VALUES(8,'Павловский завод');
INSERT INTO "Suplyers" VALUES(9,'Weber');
INSERT INTO "Suplyers" VALUES(10,'Hesler');
INSERT INTO "Suplyers" VALUES(11,'Armero');
INSERT INTO "Suplyers" VALUES(12,'Wenzo Roma');
INSERT INTO "Suplyers" VALUES(13,'KILIMGRIN');
INSERT INTO "Suplyers" VALUES(14,'Исток');
INSERT INTO "Suplyers" VALUES(15,'RUIZ');
INSERT INTO "Suplyers" VALUES(16,'Husqvarna');
INSERT INTO "Suplyers" VALUES(17,'Delta');
CREATE TABLE "Users" (
        "ID" INTEGER PRIMARY KEY AUTOINCREMENT,
        "Last_Name" VARCHAR(100) NOT NULL,
        "First_Name" VARCHAR(100) NOT NULL,
        "Middle_Name" VARCHAR(100) NOT NULL,
        "Login" VARCHAR(200) NOT NULL UNIQUE,
        "Password" VARCHAR(100) NOT NULL,
        "Role_ID" INTEGER NOT NULL REFERENCES "Roles"("ID"));
INSERT INTO "Users" VALUES(1,'Ворсин','Петр','Евгеньевич','94d5ous@gmail.com','uzWC67',1);
INSERT INTO "Users" VALUES(2,'Старикова','Елена','Павловна','uth4iz@mail.com','2L6KZG',1);
INSERT INTO "Users" VALUES(3,'Одинцов','Серафим','Артёмович','yzls62@outlook.com','JlFRCZ',1);
INSERT INTO "Users" VALUES(4,'Степанов','Михаил','Артёмович','1diph5e@tutanota.com','8ntwUp',2);
INSERT INTO "Users" VALUES(5,'Ворсин','Петр','Евгеньевич','tjde7c@yahoo.com','YOyhfR',2);
INSERT INTO "Users" VALUES(6,'Старикова','Елена','Павловна','wpmrc3do@tutanota.com','RSbvHv',2);
INSERT INTO "Users" VALUES(7,'Михайлюк','Анна','Вячеславовна','5d4zbu@tutanota.com','rwVDh9',3);
INSERT INTO "Users" VALUES(8,'Ситдикова','Елена','Анатольевна','ptec8ym@yahoo.com','LdNyos',3);
INSERT INTO "Users" VALUES(9,'Никифорова','Весения','Николаевна','1qz4kw@mail.com','gynQMT',3);
INSERT INTO "Users" VALUES(10,'Сазонов','Руслан','Германович','4np6se@mail.com','AtnDjr',3);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('Roles',3);
INSERT INTO "sqlite_sequence" VALUES('Users',10);
INSERT INTO "sqlite_sequence" VALUES('Category',5);
INSERT INTO "sqlite_sequence" VALUES('Manufactures',17);
INSERT INTO "sqlite_sequence" VALUES('Suplyers',17);
INSERT INTO "sqlite_sequence" VALUES('Pickups',36);
COMMIT;
