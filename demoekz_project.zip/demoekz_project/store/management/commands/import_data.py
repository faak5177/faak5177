import csv
import os
from django.core.management.base import BaseCommand
from store.models import Role, User, Category, Manufacturer, Supplier, Product, PickPoint

class Command(BaseCommand):
    help = 'Import data from CSV files'

    def handle(self, *args, **options):
        base_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
        )

        self._import_roles(base_dir)
        self._import_users(base_dir)
        self._import_categories(base_dir)
        self._import_manufacturers(base_dir)
        self._import_suppliers(base_dir)
        self._import_products(base_dir)
        self._import_pickpoints(base_dir)

        self.stdout.write(self.style.SUCCESS('Данные успешно импортированы!'))

    def _import_roles(self, base_dir):
        Role.objects.all().delete()
        path = os.path.join(base_dir, 'Роли.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                Role.objects.create(id=int(row['ID']), name=row['Name'])
        self.stdout.write(f'Роли импортированы: {Role.objects.count()}')

    def _import_users(self, base_dir):
        User.objects.all().delete()
        path = os.path.join(base_dir, 'Пользователи.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                User.objects.create(
                    id=int(row['ID']),
                    last_name=row['Last_Name'],
                    first_name=row['First_Name'],
                    middle_name=row['Middle_Name'],
                    login=row['Login'],
                    password=row['Password'],
                    role_id=int(row['Role_ID']),
                )
        self.stdout.write(f'Пользователи импортированы: {User.objects.count()}')

    def _import_categories(self, base_dir):
        Category.objects.all().delete()
        path = os.path.join(base_dir, 'Категории.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                Category.objects.create(id=int(row['ID']), name=row['Name'])
        self.stdout.write(f'Категории импортированы: {Category.objects.count()}')

    def _import_manufacturers(self, base_dir):
        Manufacturer.objects.all().delete()
        path = os.path.join(base_dir, 'Производители.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                Manufacturer.objects.create(id=int(row['ID']), name=row['Name'])
        self.stdout.write(f'Производители импортированы: {Manufacturer.objects.count()}')

    def _import_suppliers(self, base_dir):
        Supplier.objects.all().delete()
        path = os.path.join(base_dir, 'Поставщики.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                Supplier.objects.create(id=int(row['ID']), name=row['Name'])
        self.stdout.write(f'Поставщики импортированы: {Supplier.objects.count()}')

    def _import_products(self, base_dir):
        Product.objects.all().delete()
        path = os.path.join(base_dir, 'Товары.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                Product.objects.create(
                    article=row['Article'],
                    name=row['Name'],
                    number_measure=row['number_measure'],
                    price=row['Price'],
                    supplier_id=int(row['Supplier_ID']),
                    manufacturer_id=int(row['Manufacturer_ID']),
                    category_id=int(row['Category_ID']),
                    discount=row['Discount'],
                    quantity=int(row['Quantity']),
                    description=row['Description'] if row['Description'] else '',
                    photo=row['Photo'] if row['Photo'] else '',
                )
        self.stdout.write(f'Товары импортированы: {Product.objects.count()}')

    def _import_pickpoints(self, base_dir):
        PickPoint.objects.all().delete()
        path = os.path.join(base_dir, 'Точки подбора.csv')
        with open(path, encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                PickPoint.objects.create(
                    zip_code=row['Zip_Code'],
                    city=row['City'],
                    street=row['Street'],
                    house=row['House'] if row['House'] else '',
                )
        self.stdout.write(f'Точки подбора импортированы: {PickPoint.objects.count()}')
