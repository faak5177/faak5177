# Generated for SQLite — таблицы создаются командой init_db (managed=False)

from django.db import migrations

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = []
